<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

function brickpoint_elementor_support() {
  add_theme_support( 'elementor' );
  add_theme_support( 'elementor-theme-builder' );
  // Declare header/footer/single/archive locations for Elementor Pro Theme Builder.
  add_theme_support( 'elementor-pro-locations' );
}
add_action( 'after_setup_theme', 'brickpoint_elementor_support' );

// Render Elementor Pro header/footer locations when available.
function brickpoint_do_location( $location ) {
  if ( function_exists( 'elementor_theme_do_location' ) && elementor_theme_do_location( $location ) ) {
    return true;
  }
  return false;
}
