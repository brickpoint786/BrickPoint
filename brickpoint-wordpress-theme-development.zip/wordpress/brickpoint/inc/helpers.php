<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

function bp_get( $key, $default = '' ) {
  $v = get_theme_mod( $key, $default );
  return $v !== '' ? $v : $default;
}
function bp_phone_display() { return bp_get( 'bp_phone_display', '0315 2850818' ); }
function bp_phone_intl() {
  $p = preg_replace( '/\D/', '', bp_get( 'bp_whatsapp_number', '923152850818' ) );
  return $p ? $p : '923152850818';
}
function bp_email() { return sanitize_email( bp_get( 'bp_email', 'info@brickpoint.pk' ) ); }
function bp_social( $network ) {
  $defaults = array(
    'facebook'  => 'https://www.facebook.com/brickpoint.pk/',
    'instagram' => 'https://www.instagram.com/brickpoint.pk/',
    'twitter'   => 'https://x.com/BrickPointPK',
    'tiktok'    => 'https://www.tiktok.com/@brickpoint.pk/',
  );
  return esc_url( bp_get( 'bp_social_' . $network, isset( $defaults[ $network ] ) ? $defaults[ $network ] : '' ) );
}
function bp_meta( $post_id, $key, $default = '' ) {
  $v = get_post_meta( $post_id, $key, true );
  return ( $v === '' || $v === null ) ? $default : $v;
}
function bp_term_image( $term_id, $key = 'bp_cat_image' ) {
  return esc_url( get_term_meta( $term_id, $key, true ) );
}
function bp_breadcrumbs( $sep = ' / ' ) {
  $items = array( '<a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Home', 'brickpoint' ) . '</a>' );
  if ( is_singular( 'bp_product' ) ) {
    $items[] = '<a href="' . esc_url( get_post_type_archive_link( 'bp_product' ) ) . '">' . esc_html__( 'Products', 'brickpoint' ) . '</a>';
    $items[] = '<span>' . esc_html( get_the_title() ) . '</span>';
  } elseif ( is_singular( 'bp_video' ) ) {
    $items[] = '<a href="' . esc_url( get_post_type_archive_link( 'bp_video' ) ) . '">' . esc_html__( 'Videos', 'brickpoint' ) . '</a>';
    $items[] = '<span>' . esc_html( get_the_title() ) . '</span>';
  } elseif ( is_singular( 'post' ) ) {
    $items[] = '<a href="' . esc_url( get_permalink( get_option( 'page_for_posts' ) ) ) . '">' . esc_html__( 'Blog', 'brickpoint' ) . '</a>';
    $items[] = '<span>' . esc_html( get_the_title() ) . '</span>';
  } elseif ( is_archive() ) {
    $items[] = '<span>' . esc_html( get_the_archive_title() ) . '</span>';
  } elseif ( is_search() ) {
    $items[] = '<span>' . sprintf( esc_html__( 'Search: %s', 'brickpoint' ), esc_html( get_search_query() ) ) . '</span>';
  } else {
    $items[] = '<span>' . esc_html( get_the_title() ) . '</span>';
  }
  echo '<nav class="bp-breadcrumbs" aria-label="Breadcrumb">' . wp_kses_post( implode( esc_html( $sep ), $items ) ) . '</nav>';
}
function bp_excerpt( $length = 24 ) {
  $text = get_the_excerpt() ? get_the_excerpt() : get_the_content();
  return wp_trim_words( wp_strip_all_tags( $text ), absint( $length ), '…' );
}
