<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header(); ?>
<div class="bp-container bp-section bp-center">
  <p class="bp-eyebrow"><?php esc_html_e( 'Error 404', 'brickpoint' ); ?></p>
  <h1><?php esc_html_e( 'Page not found', 'brickpoint' ); ?></h1>
  <p><?php esc_html_e( 'The page you requested could not be found. Try the homepage or product catalogue.', 'brickpoint' ); ?></p>
  <p class="bp-mt"><a class="btn-brick" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Back to Home', 'brickpoint' ); ?></a>
  <a class="btn-ghost" href="<?php echo esc_url( get_post_type_archive_link( 'bp_product' ) ); ?>"><?php esc_html_e( 'Browse Products', 'brickpoint' ); ?></a></p>
</div>
<?php get_footer(); ?>
