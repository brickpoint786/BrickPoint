<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'bp-card' ); ?>>
  <a class="bp-card-media" href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'bp-card' ); ?></a>
  <div class="bp-card-body">
    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
    <p><?php echo esc_html( bp_excerpt( 20 ) ); ?></p>
    <?php brickpoint_posted_meta(); ?>
  </div>
</article>
