<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
$d = brickpoint_hero_defaults();
$video = bp_get( 'bp_hero_video', '' ); $poster = bp_get( 'bp_hero_poster', '' );
?>
<section class="bp-hero">
  <div class="bp-container bp-hero-grid">
    <div class="bp-hero-copy">
      <p class="bp-hero-kicker"><?php esc_html_e( 'Masha Allah • Fine Bricks • SS7', 'brickpoint' ); ?></p>
      <h1><?php echo esc_html( $d['title'] ); ?></h1>
      <p><?php echo esc_html( $d['subtitle'] ); ?></p>
      <p class="bp-hero-cta">
        <a class="btn-brick" href="<?php echo esc_url( get_post_type_archive_link( 'bp_product' ) ); ?>"><?php esc_html_e( 'Explore Products', 'brickpoint' ); ?></a>
        <a class="btn-ghost" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><?php esc_html_e( 'Request a Quote', 'brickpoint' ); ?></a>
        <a class="btn-whatsapp" target="_blank" rel="noopener" href="<?php echo esc_url( bp_whatsapp_url( bp_get( 'bp_default_wa', 'Assalam-o-Alaikum BrickPoint' ) ) ); ?>"><?php esc_html_e( 'WhatsApp Us', 'brickpoint' ); ?></a>
      </p>
    </div>
    <div class="bp-hero-media">
      <?php if ( $video ) : ?>
        <video class="bp-hero-video" autoplay muted loop playsinline preload="metadata" <?php if ( $poster ) : ?>poster="<?php echo esc_url( $poster ); ?>"<?php endif; ?>>
          <source src="<?php echo esc_url( $video ); ?>" type="video/mp4" />
        </video>
      <?php elseif ( has_post_thumbnail() ) : the_post_thumbnail( 'bp-hero' ); endif; ?>
      <div class="bp-ss7-float"><div class="ss7-brick"><strong>SS7</strong><span><?php esc_html_e( 'Flagship Bricks', 'brickpoint' ); ?></span></div></div>
    </div>
  </div>
</section>
