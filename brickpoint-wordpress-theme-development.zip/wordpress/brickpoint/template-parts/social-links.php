<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div class="bp-social">
  <a href="<?php echo bp_social( 'facebook' ); ?>" target="_blank" rel="noopener" aria-label="Facebook">f</a>
  <a href="<?php echo bp_social( 'instagram' ); ?>" target="_blank" rel="noopener" aria-label="Instagram">ig</a>
  <a href="<?php echo bp_social( 'twitter' ); ?>" target="_blank" rel="noopener" aria-label="X">x</a>
  <a href="<?php echo bp_social( 'tiktok' ); ?>" target="_blank" rel="noopener" aria-label="TikTok">t</a>
</div>
