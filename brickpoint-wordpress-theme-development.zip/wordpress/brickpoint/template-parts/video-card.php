<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
$id = get_the_ID();
$dur = bp_meta( $id, '_bpv_duration', '' );
$feat = bp_meta( $id, '_bpv_featured', '0' ) === '1';
$cats = get_the_terms( $id, 'bp_video_category' );
$catname = ( $cats && ! is_wp_error( $cats ) ) ? $cats[0]->name : '';
?>
<article class="bp-card bp-video-card">
  <a class="bp-card-media bp-video-thumb" href="<?php the_permalink(); ?>">
    <?php the_post_thumbnail( 'bp-card' ); ?>
    <span class="bp-play-btn" aria-hidden="true">▶</span>
    <?php if ( $dur ) : ?><span class="bp-duration"><?php echo esc_html( $dur ); ?></span><?php endif; ?>
    <?php if ( $feat ) : ?><span class="bp-feat"><?php esc_html_e( 'Featured', 'brickpoint' ); ?></span><?php endif; ?>
  </a>
  <div class="bp-card-body">
    <?php if ( $catname ) : ?><p class="bp-eyebrow"><?php echo esc_html( $catname ); ?></p><?php endif; ?>
    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
    <p><?php echo esc_html( bp_excerpt( 16 ) ); ?></p>
  </div>
</article>
