<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
while ( have_posts() ) : the_post(); ?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'bp-page' ); ?>>
  <div class="bp-pagehead"><div class="bp-container">
    <h1><?php the_title(); ?></h1>
    <?php bp_breadcrumbs(); ?>
  </div></div>
  <div class="bp-container bp-section bp-entry"><?php the_content(); ?></div>
</article>
<?php endwhile; get_footer(); ?>
