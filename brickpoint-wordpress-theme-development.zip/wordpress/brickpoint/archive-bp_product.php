<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header(); ?>
<div class="bp-pagehead"><div class="bp-container">
  <p class="bp-eyebrow"><?php esc_html_e( 'Catalogue', 'brickpoint' ); ?></p>
  <h1><?php esc_html_e( 'Products', 'brickpoint' ); ?></h1>
  <div class="bp-filters">
    <?php $cats = get_terms( array( 'taxonomy' => 'bp_product_category', 'hide_empty' => false ) );
    if ( $cats && ! is_wp_error( $cats ) ) : foreach ( $cats as $t ) : ?>
      <a href="<?php echo esc_url( get_term_link( $t ) ); ?>"><?php echo esc_html( $t->name ); ?></a>
    <?php endforeach; endif; ?>
  </div>
</div></div>
<div class="bp-container bp-section"><div class="bp-grid cols-4">
  <?php while ( have_posts() ) : the_post(); get_template_part( 'template-parts/product-card' ); endwhile; ?>
</div><?php brickpoint_pagination(); ?></div>
<?php get_footer(); ?>
