<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
while ( have_posts() ) : the_post();
  $id = get_the_ID();
  $price = bp_meta( $id, '_bp_price', '' ); $unit = bp_meta( $id, '_bp_unit', '' );
  $avail = bp_meta( $id, '_bp_availability', 'In Stock' ); $badge = bp_meta( $id, '_bp_badge', '' );
  $label = bp_meta( $id, '_bp_price_label', '' ); $sku = bp_meta( $id, '_bp_sku', '' );
  $video = bp_meta( $id, '_bp_video', '' ); $vtype = bp_meta( $id, '_bp_video_type', 'mp4' );
  $brochure = bp_meta( $id, '_bp_brochure', '' );
  $cats = get_the_terms( $id, 'bp_product_category' );
  $catname = ( $cats && ! is_wp_error( $cats ) ) ? $cats[0]->name : '';
  $msg = bp_product_whatsapp_message( $id );
  $gallery = array_values( array_filter( array_map( 'trim', preg_split( '/\r?\n/', bp_meta( $id, '_bp_gallery', '' ) ) ) ) );
  $specs = array_values( array_filter( array_map( 'trim', preg_split( '/\r?\n/', bp_meta( $id, '_bp_specs', '' ) ) ) ) );
  $features = array_values( array_filter( array_map( 'trim', preg_split( '/\r?\n/', bp_meta( $id, '_bp_features', '' ) ) ) ) );
?>
<article class="bp-product-single">
  <div class="bp-container bp-crumbs"><?php bp_breadcrumbs(); ?></div>
  <div class="bp-container bp-product-layout">
    <div class="bp-product-media">
      <?php if ( has_post_thumbnail() ) : the_post_thumbnail( 'bp-hero', array( 'class' => 'bp-product-img' ) ); endif; ?>
      <?php if ( $gallery ) : ?><div class="bp-thumbs"><?php foreach ( $gallery as $g ) : ?><img src="<?php echo esc_url( $g ); ?>" alt="" loading="lazy" /><?php endforeach; ?></div><?php endif; ?>
      <?php if ( $video ) : ?><div class="bp-product-video">
        <?php if ( $vtype === 'youtube' || $vtype === 'vimeo' ) : ?>
          <iframe src="<?php echo esc_url( $video ); ?>" loading="lazy" allowfullscreen></iframe>
        <?php else : ?>
          <video controls playsinline preload="metadata" src="<?php echo esc_url( $video ); ?>"></video>
        <?php endif; ?>
      </div><?php endif; ?>
    </div>
    <div class="bp-product-info">
      <?php if ( $catname ) : ?><p class="bp-eyebrow"><?php echo esc_html( $catname ); ?></p><?php endif; ?>
      <h1><?php the_title(); ?></h1>
      <?php $short = bp_meta( $id, '_bp_short', '' ); if ( $short ) : ?><p class="bp-short"><?php echo esc_html( $short ); ?></p><?php endif; ?>
      <p class="bp-price-row">
        <?php if ( $price ) : ?><span class="bp-price"><?php echo esc_html( $price ); ?></span><?php if ( $unit ) : ?><span class="bp-unit">/ <?php echo esc_html( $unit ); ?></span><?php endif; ?>
        <?php else : ?><span class="bp-price"><?php esc_html_e( 'Price on request', 'brickpoint' ); ?></span><?php endif; ?>
        <span class="bp-avail"><?php echo esc_html( $avail ); ?></span>
        <?php if ( $badge ) : ?><span class="bp-badge"><?php echo esc_html( $badge ); ?></span><?php endif; ?>
      </p>
      <?php if ( $label ) : ?><p class="bp-muted"><?php echo esc_html( $label ); ?></p><?php endif; ?>
      <?php if ( $sku ) : ?><p class="bp-muted">SKU: <strong><?php echo esc_html( $sku ); ?></strong></p><?php endif; ?>
      <div class="bp-product-cta">
        <a class="btn-whatsapp" target="_blank" rel="noopener" href="<?php echo esc_url( bp_whatsapp_url( $msg ) ); ?>"><?php esc_html_e( 'Request Quote on WhatsApp', 'brickpoint' ); ?></a>
        <a class="btn-dark" href="tel:<?php echo esc_attr( bp_phone_intl() ); ?>"><?php echo esc_html( bp_phone_display() ); ?></a>
        <a class="btn-brick" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><?php esc_html_e( 'Request Quotation', 'brickpoint' ); ?></a>
      </div>
      <?php if ( $features ) : ?><div class="bp-box"><h3><?php esc_html_e( 'Key Features', 'brickpoint' ); ?></h3><ul><?php foreach ( $features as $f ) : ?><li><?php echo esc_html( $f ); ?></li><?php endforeach; ?></ul></div><?php endif; ?>
      <?php if ( $specs ) : ?><div class="bp-box"><h3><?php esc_html_e( 'Specifications', 'brickpoint' ); ?></h3><dl><?php foreach ( $specs as $s ) : $p = explode( ':', $s, 2 ); ?><div><dt><?php echo esc_html( trim( $p[0] ) ); ?></dt><dd><?php echo esc_html( isset( $p[1] ) ? trim( $p[1] ) : '' ); ?></dd></div><?php endforeach; ?></dl></div><?php endif; ?>
      <div class="bp-entry"><?php the_content(); ?></div>
      <?php if ( $brochure ) : ?><p><a class="btn-ghost" target="_blank" rel="noopener" href="<?php echo esc_url( $brochure ); ?>"><?php esc_html_e( 'Download Brochure (PDF)', 'brickpoint' ); ?></a></p><?php endif; ?>
    </div>
  </div>
  <div class="bp-container bp-section">
    <h2><?php esc_html_e( 'Related Products', 'brickpoint' ); ?></h2>
    <div class="bp-grid cols-4">
      <?php $rel = new WP_Query( array( 'post_type' => 'bp_product', 'posts_per_page' => 4, 'post__not_in' => array( $id ) ) );
      while ( $rel->have_posts() ) : $rel->the_post(); get_template_part( 'template-parts/product-card' ); endwhile; wp_reset_postdata(); ?>
    </div>
  </div>
</article>
<?php endwhile; get_footer(); ?>
