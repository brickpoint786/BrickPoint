<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header(); ?>
<div class="bp-pagehead"><div class="bp-container">
  <p class="bp-eyebrow"><?php esc_html_e( 'Guides & Updates', 'brickpoint' ); ?></p>
  <h1><?php esc_html_e( 'Blog', 'brickpoint' ); ?></h1>
  <?php get_search_form(); ?>
</div></div>
<div class="bp-container bp-section"><div class="bp-grid cols-3">
  <?php while ( have_posts() ) : the_post(); get_template_part( 'template-parts/content' ); endwhile; ?>
</div><?php brickpoint_pagination(); ?></div>
<?php get_footer(); ?>
