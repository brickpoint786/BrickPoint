<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
while ( have_posts() ) : the_post(); $id = get_the_ID(); ?>
<article class="bp-video-single">
  <div class="bp-container bp-crumbs"><?php bp_breadcrumbs(); ?></div>
  <div class="bp-container bp-section">
    <?php echo bp_video_embed_html( $id, array( 'controls' => true ) ); // phpcs:ignore ?>
    <p class="bp-eyebrow bp-mt"><?php $t = get_the_terms( $id, 'bp_video_category' ); echo ( $t && ! is_wp_error( $t ) ) ? esc_html( $t[0]->name ) : ''; ?></p>
    <h1><?php the_title(); ?></h1>
    <div class="bp-entry"><?php the_content(); ?></div>
    <h2 class="bp-mt"><?php esc_html_e( 'More Videos', 'brickpoint' ); ?></h2>
    <div class="bp-grid cols-3">
      <?php $m = new WP_Query( array( 'post_type' => 'bp_video', 'posts_per_page' => 3, 'post__not_in' => array( $id ) ) );
      while ( $m->have_posts() ) : $m->the_post(); get_template_part( 'template-parts/video-card' ); endwhile; wp_reset_postdata(); ?>
    </div>
  </div>
</article>
<?php endwhile; get_footer(); ?>
